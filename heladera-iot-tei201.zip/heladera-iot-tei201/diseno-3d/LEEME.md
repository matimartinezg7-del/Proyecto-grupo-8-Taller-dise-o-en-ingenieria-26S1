# Carpeta Diseño 3D

Subir aquí (exportados desde Fusion 360):
- `encapsulado.f3d` o `.f3z` — el ENSAMBLE completo: carcasa + volúmenes
  referenciales de cada componente (ESP8266, RC522, batería/cable). No solo la caja.
- `planos.pdf` — vistas ortogonales con cotas y escala.
- `renders/` — al menos una vista exterior y una interior o explosionada.

Recordatorio rúbrica: un encapsulado vacío (sin componentes internos) NO cuenta
como gemelo 3D. Una imagen del modelo NO es un plano técnico.
