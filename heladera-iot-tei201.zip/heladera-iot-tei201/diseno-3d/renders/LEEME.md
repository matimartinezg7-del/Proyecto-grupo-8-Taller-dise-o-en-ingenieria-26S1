Subir aquí los renders: vista exterior + vista interior o explosionada.
Aplicar materiales e iluminación para mejor nota.
