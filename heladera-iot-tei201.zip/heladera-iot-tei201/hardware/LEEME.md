# Carpeta Hardware

Subir aquí:
- `esquematico.png` (o .pdf) — diagrama de conexiones del ESP8266 con el RC522.
  Hacerlo en Fritzing o Wokwi. Debe mostrar todos los pines (D3=RST, D4=SS,
  D5=SCK, D6=MISO, D7=MOSI, 3V3, GND).
- `BOM.csv` — ya incluido. Verificar costos reales y completar si falta algo.
- Fotos del prototipo ensamblado desde al menos 3 ángulos (pueden ir aquí o en docs).
