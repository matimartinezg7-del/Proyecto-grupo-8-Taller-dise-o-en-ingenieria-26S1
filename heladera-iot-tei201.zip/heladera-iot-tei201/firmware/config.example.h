/*
 * config.example.h
 * ----------------------------------------------------------------------------
 * Plantilla de credenciales. Para usar el proyecto:
 *   1. Copien este archivo y renombrenlo a "config.h"
 *   2. Completen sus datos reales abajo
 *   3. config.h NO se sube al repositorio (esta en .gitignore)
 *
 * Esto evita exponer tokens y contrasenas en GitHub.
 * ----------------------------------------------------------------------------
 */
#ifndef CONFIG_H
#define CONFIG_H

// -------- WIFI --------
const char* ssid     = "TU_RED_WIFI";
const char* password = "TU_PASSWORD_WIFI";

// -------- TELEGRAM --------
#define BOT_TOKEN "TU_BOT_TOKEN"
#define CHAT_ID   "TU_CHAT_ID"

// -------- FIREBASE --------
// Sin "https://" ni "/" final, solo el host:
#define FIREBASE_HOST "tu-proyecto-default-rtdb.firebaseio.com"
// Database Secret (Configuracion del proyecto -> Cuentas de servicio ->
// Secretos de la base de datos):
#define FIREBASE_AUTH "TU_DATABASE_SECRET"

#endif
