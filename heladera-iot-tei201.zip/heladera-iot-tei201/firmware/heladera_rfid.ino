/*
 * ============================================================================
 *  Heladera Inteligente IoT - Control de vencimientos por RFID
 *  TEI201 - Taller de Diseno en Ingenieria - UAI
 * ============================================================================
 *
 *  Hardware:  NodeMCU ESP8266 + lector RFID-RC522
 *  Funcion:   Al escanear un alimento (etiqueta RFID), el sistema:
 *               1. Identifica el alimento por su UID
 *               2. Registra fecha de ingreso y calcula la de vencimiento
 *               3. Sube el registro a Firebase Realtime Database
 *               4. Envia una notificacion por Telegram
 *
 *  IMPORTANTE: las credenciales (WiFi, Telegram, Firebase) van en config.h,
 *  que NO se sube al repositorio (ver .gitignore). Copien config.example.h
 *  como config.h y completen sus datos.
 * ============================================================================
 */

#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <SPI.h>
#include <MFRC522.h>
#include <time.h>
#include <FirebaseESP8266.h>   // Libreria "Firebase ESP Client" de Mobizt

#include "config.h"            // Credenciales (no versionado)

// -------- PINES RC522 (NodeMCU) --------
#define RST_PIN  D3            // Reset del lector
#define SS_PIN   D4            // Slave Select (SDA)
MFRC522 mfrc522(SS_PIN, RST_PIN);

// -------- OBJETOS GLOBALES --------
WiFiClientSecure client;
UniversalTelegramBot bot(BOT_TOKEN, client);

FirebaseData fbdo;
FirebaseConfig fbConfig;
FirebaseAuth fbAuth;

// ============================================================================
//  TABLA DE ALIMENTOS
//  Asocia el UID de cada etiqueta RFID con un nombre y una duracion (en dias).
//  COMPLETAR con los UID reales de sus etiquetas (se imprimen en el Serial al
//  escanear una etiqueta no registrada).
// ============================================================================
struct Alimento {
  const char* uid;          // UID de la etiqueta, ej "04 39 88 4A BA 2A 81"
  const char* nombre;       // Nombre del alimento
  int duracion_dias;        // Dias estimados hasta el vencimiento
};

Alimento alimentos[] = {
  { "04 39 88 4A BA 2A 81", "Lechuga",  5 },
  { "00 00 00 00 00 00 00", "Leche",    7 },   // <-- reemplazar UID real
  { "00 00 00 00 00 00 00", "Tomate",   6 },   // <-- reemplazar UID real
  // Agregar mas alimentos aqui...
};
const int N_ALIMENTOS = sizeof(alimentos) / sizeof(alimentos[0]);

// ============================================================================
//  SETUP
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(100);

  // --- WiFi ---
  Serial.print("Conectando a WiFi");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi conectado. IP: " + WiFi.localIP().toString());

  // Telegram usa HTTPS: para esta etapa se omite la verificacion del certificado
  client.setInsecure();

  // --- Hora por NTP (necesaria para fechas correctas) ---
  configTime(-3 * 3600, 0, "pool.ntp.org", "time.nist.gov"); // GMT-3 (Chile)
  Serial.print("Sincronizando hora");
  time_t now = time(nullptr);
  while (now < 8 * 3600 * 2) {
    delay(500);
    Serial.print(".");
    now = time(nullptr);
  }
  Serial.println(" OK");

  // --- RFID ---
  SPI.begin();
  mfrc522.PCD_Init();
  Serial.println("Lector RFID listo.");

  // --- Firebase ---
  fbConfig.database_url = FIREBASE_HOST;
  fbConfig.signer.tokens.legacy_token = FIREBASE_AUTH;
  Firebase.begin(&fbConfig, &fbAuth);
  Firebase.reconnectWiFi(true);
  Serial.println("Firebase inicializado.");

  Serial.println("Sistema listo. Acerque un alimento al lector.\n");
}

// ============================================================================
//  LOOP
// ============================================================================
void loop() {
  // Espera a que haya una etiqueta nueva
  if (!mfrc522.PICC_IsNewCardPresent() || !mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  // Construye el UID como texto
  String uid = leerUID();
  Serial.println("Etiqueta detectada: " + uid);

  // Busca el alimento en la tabla
  int idx = buscarAlimento(uid);
  if (idx == -1) {
    Serial.println(">> UID no registrado. Agregalo a la tabla 'alimentos'.\n");
    mfrc522.PICC_HaltA();
    return;
  }

  registrarAlimento(alimentos[idx]);

  mfrc522.PICC_HaltA();          // Detiene la lectura de esta etiqueta
  mfrc522.PCD_StopCrypto1();
  delay(2000);                   // Evita lecturas repetidas inmediatas
}

// ============================================================================
//  FUNCIONES AUXILIARES
// ============================================================================

// Devuelve el UID de la etiqueta actual como string "XX XX XX ..."
String leerUID() {
  String uid = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    if (mfrc522.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(mfrc522.uid.uidByte[i], HEX);
    if (i < mfrc522.uid.size - 1) uid += " ";
  }
  uid.toUpperCase();
  return uid;
}

// Busca un UID en la tabla; devuelve el indice o -1 si no existe
int buscarAlimento(String uid) {
  for (int i = 0; i < N_ALIMENTOS; i++) {
    if (uid == String(alimentos[i].uid)) return i;
  }
  return -1;
}

// Registra el alimento: calcula fechas, sube a Firebase y avisa por Telegram
void registrarAlimento(Alimento a) {
  time_t ahora = time(nullptr);
  time_t vence = ahora + (time_t)a.duracion_dias * 24 * 3600;

  String fechaIngreso = formatearFecha(ahora);
  String fechaVence   = formatearFecha(vence);

  Serial.println("Registrando: " + String(a.nombre));
  Serial.println("  Ingreso:    " + fechaIngreso);
  Serial.println("  Vence:      " + fechaVence);

  // --- Subir a Firebase ---
  FirebaseJson json;
  json.set("nombre", a.nombre);
  json.set("uid", String(leerUID()));
  json.set("fecha_ingreso", fechaIngreso);
  json.set("fecha_expiracion", fechaVence);
  json.set("duracion_dias", a.duracion_dias);
  json.set("timestamp", (int)ahora);

  if (Firebase.pushJSON(fbdo, "/alimentos", json)) {
    Serial.println("  Firebase:   OK (push en /alimentos)");
  } else {
    Serial.println("  Firebase:   ERROR -> " + fbdo.errorReason());
  }
  // Sobrescribe el ultimo alimento leido (acceso rapido para el dashboard)
  Firebase.setJSON(fbdo, "/ultimo", json);

  // --- Avisar por Telegram ---
  String msg = "Nuevo alimento registrado:\n";
  msg += "Nombre: " + String(a.nombre) + "\n";
  msg += "Ingreso: " + fechaIngreso + "\n";
  msg += "Vence: " + fechaVence;
  bot.sendMessage(CHAT_ID, msg, "");
  Serial.println("  Telegram:   enviado\n");
}

// Formatea un time_t como "DD/MM/YYYY HH:MM"
String formatearFecha(time_t t) {
  struct tm* tm_info = localtime(&t);
  char buffer[20];
  strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M", tm_info);
  return String(buffer);
}
